A lightweight progress bar directive that is focused on providing progress visualization! 

The progress bar directive supports multiple (stacked) bars into the same element, optional transition animation, event handler for full & empty state and many more.
